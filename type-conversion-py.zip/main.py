'''

                            Online Python Compiler.
                Code, Compile, Run and Debug python program online.
Write your code in this editor and press "Run" button to execute it.

'''


x = 10
 
print("x is of type:",type(x))
 
y = 10.6
print("y is of type:",type(y))
 
x = x + y
 
print(x)
print("x is of type:",type(x))
